
   ## Hi there 👋

<h1 align="center">ꪶBADBOI-v3 BUGꫂ<br></h1>
<p align="center">
<img src="https://telegra.ph/file/7e30e2a345f986b958e83.jpg" />
</p>

<p align="center">
BADBOI-v3 𝘽𝙤𝙩 Multi Device is a whatsapp bot created by <a href="https://github.com/BADBOI-v1" target="_blank">BADBOI</a> using <a href="https://github.com/adiwajshing/Baileys" target="_blank">Baileys</a> and <a href="https://github.com/nodejs" target="_blank">Nodejs</a>. Dont forget to give a star bro.
</p>
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+_____BADBOI+v3_____;WHATSAPP+CRASH+x+BUG+BOT;DEVELOPED+BY+BAD+BOI;REALESE+DATE+14%2F7%2F2024." alt="Typing SVG" /></a>
</p>
# ```Bot Info```
<p align="center">
<a href="https://github.com/BADBOI-v1/followers"><img title="Followers" src="https://img.shields.io/github/followers/BADBOI-v1?color=red&style=flat-square"></a>
<a href="https://github.com/BADBOI-v1/BADBOI-v3/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/BADBOI-v1/BADBOI-v3?color=blue&style=flat-square"></a>
<a href="https://github.com/BADBOI-v1/BADBOI-v3/network/members"><img title="Forks" src="https://img.shields.io/github/forks/BADBOI-v1/BADBOI-v3?color=red&style=flat-square"></a>
<a href="https://github.com/BADBOI-v1/BADBOI-v3/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/BADBOI-v1/BADBOI-v3?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/BADBOI-v1/BADBOI-v3"><img title="Open Source" src="https://img.shields.io/badge/Author-BADBOI%20Bot%20Inc.-red?v=103"></a>
<a href="https://github.com/BADBOI-v1/BADBOI-v3/"><img title="Size" src="https://img.shields.io/github/repo-size/BADBOI-v1/BADBOI-v3?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2BADBOI-v1%2FBLACK BADBOI-v1BUG&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/BADBOI-v1/BADBOI-v3/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;

-------
## ```YOUTUBE CHANNEL FOR TUTORIALS```

 - [ Click ](https://youtube.com/@BADBOI-k2i?si=1_Ae2h9Kl9IbAo7E)

### If you want to deploy somewhere else, upload your creds.json in session folder after getting pair code on replit or render. 

### 1. <a href="https://github.com/BADBOI-v1/BADBOI-v3/fork"><img src="https://img.shields.io/badge/FORK-blue" alt="Click Here to fork BADBOI-v2" width="70"></a>
## `Generate Pair Code For Session`
 
[`Badboi-v3 Pairing Using Render`](https://badboi.onrender.com/)

[`Badboi-v3 Pairing using Replit`](https://replit.com/@samjame088/Xeon-PairCode-1)


### . <a href="https://pylexnodes.net"><img src="https://img.shields.io/badge/DEPLOY ON PANEL-black" alt="Click Here to Deploy on Panel" width="120"></a>

### . <a href="https://dashboard.toystack.ai/login"><img src="https://img.shields.io/badge/DEPLOY ON TOYSTACK AI -black" alt="Click Here to Deploy on TOYSTACK AI" width="120"></a>

# Instalasi
## Heroku Buildpack
```bash
heroku/nodejs
```
```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
```
```
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

*Add your Creds.json to Session file
* Create a new app at [Heroku](https://id.heroku.com/login)
* Add Build packs
* Connect your heroku with your github
* Locate BADBOI-v3-BUG
* Now deploy.
* Start the Worker
* Enjoy the Bot.

DEPLOY TO PANEL

Fork the repo
Edit then Download your forked repo zip
🖥 Go to panel and upload your Sc.
Delete the cred file from the session then start console
Extract or move it to a directory (container).
⌨ Use the following code to move into a container: "../"
Then go to the console and press Start.
Note: I recommend using starter + or higher for a fast bot
  
### 4. <a 
#### DEPLOY TO RENDER

 ★ Register To Render 
    <br>
<a href='https://dashboard.render.com/register' target="_blank"><img alt='Render' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

★ Now Deploy
    <br>
<a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

</br>

#### COPY THESE COMMANDS AND PASTE IF YOU TRYING TO DEPLOY [BADBOI-v3](https://github.com/BADBOI-v1/BADBOI-v3) ON ANY TERMINAL
```
sudo apt -y update && sudo apt -y upgrade
```
```
sudo apt -y install git ffmpeg curl
```
```
curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
```
```
sudo -E bash nodesource_setup.sh
```
```
sudo apt-get install -y nodejs
```
```
sudo npm install -g yarn
```
```
sudo yarn global add pm2
```
```
git clone https://github.com/type-your-username-here/BADBOI-v2
```
```
cd BADBOI-v3
```
```
yarn install
```
```
npm start
```
 


</br>
 

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
# Termux Deployment
```
termux-setup-storage
```
```
apt update
```
```
apt upgrade
```
```
pkg update && pkg upgrade
```
```
pkg install bash
```
```
pkg install libwebp
```
```
pkg install git -y
```
```
pkg install nodejs -y
```
```
pkg install ffmpeg -y 
```
```
pkg install wget
```
```
pkg install yarn
```
```
git clone (copy and paste your forked repo link not mine to save changes your changes) 
```
```
cd BADBOI-v3
```
```
yarn install
```
```
npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
- If you want Command For 24/7 (might no work) 
```js
npm i -g forever && forever index.js && forever save && forever logs
```
<br>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<br>
<h2 align="center"> 🛡️ Windows Cmd & Vs 🛡️ </h2>

- [Download ffmpeg](https://ffmpeg.org/download.html#build-windows) and set the path
- [Download wget](https://eternallybored.org/misc/wget/releases/) and set the path
- [Download Node.js](https://nodejs.org/en/download/)
- [Download Git](https://git-scm.com/downloads)
- [Download Libwebp](https://developers.google.com/speed/webp/download)

```cmd
> git clone https://github.com/BADBOI-v1/BADBOI-v3.git
```
```
> cd BADBOI-v3
```
```
> yarn install
```
```
> npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## ```Connect With Me```<img src="https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/handshake.gif" width ="80"></h1> 
 <br> 
<p align="center">
<a href="https://wa.me/2348140825959"><img src="https://img.shields.io/badge/Contact BADBOI-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://whatsapp.com/channel/0029VadCyFZGufJ2YW4bG42x"><img src="https://img.shields.io/badge/Join Official Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
   
<a href='https://chat.whatsapp.com/LYOPu85NAVv4ymxOxCxRQY' target="_blank"><img alt='Whatsapp' src='https://img.shields.io/badge/OFFICIAL-GC-h?color=black&style=for-the-badge&logo=whatsapp' width="96.35" height="28"/></a></p>

## 🎯 Authors 🎯
  <div align="center">
  
| [![BADBOI](https://github.com/BADBOI-v1.png?size=150)](https://github.com/BADBOI-v1) |
|----|
| [  Badboi Hacker](https://github.com/BADBOI-v1) |
|  Developer |

  </div>
  <div align="center">
  
| [![Tᴀɪʀᴀ Mᴀᴋɪɴᴏ](https://github.com/Anime-King01.png?size=150)](https://github.com/Anime-King01) |
|----|
| [  Lord No Name](https://github.com/Anime-King01) |
|  Co-Developer |

  </div>
   
  </br> 

<h2 align="center">  Reminder
</h2>
   
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.
 
  
  
   ## `Special Thanks To`

* [`📕 Lord No Name..!!`](https://github.com/Anime-King01)
* * [`📕 Cod3Uchiha`](https://github.com/Cod3Uchiha)
 
  * ⧉ 𝐓𝐇𝐀𝐍𝐊𝐒 𝐅𝐎𝐑 𝐓𝐇𝐄 𝐒𝐔𝐏𝐏𝐎𝐑𝐓 ⧉
  * BADBOI HACKER IS ACTIVE 😂😂😂
